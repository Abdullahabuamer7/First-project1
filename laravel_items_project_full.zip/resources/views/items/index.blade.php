<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Items</title>
</head>
<body>
    <h1>Items List</h1>
    <form action="{{ route('items.store') }}" method="POST">
        @csrf
        <label for="name">Item Name:</label>
        <input type="text" name="name" id="name" required>
        <label for="quantity">Quantity:</label>
        <input type="number" name="quantity" id="quantity" required>
        <button type="submit">Add Item</button>
    </form>
    <h2>Items:</h2>
    <ul>
        @foreach($items as $item)
            <li>{{ $item->name }} - {{ $item->quantity }}</li>
        @endforeach
    </ul>
</body>
</html>
